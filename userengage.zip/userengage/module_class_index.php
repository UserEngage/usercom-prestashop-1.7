<?php 
return array (
  'PShowUpdateException' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/PShowUpdateException.php',
    'type' => 'class',
    'override' => false,
  ),
  'PShowUpdateController' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/PShowUpdateController.php',
    'type' => 'class',
    'override' => false,
  ),
  'PShowUpdateNew' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/PShowUpdateNew.php',
    'type' => 'class',
    'override' => false,
  ),
  'PShow_Ini' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/PShow_Ini.php',
    'type' => 'class',
    'override' => false,
  ),
  'index' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/index.php',
    'type' => 'class',
    'override' => false,
  ),
  'PShowUpdate' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/PShowUpdate.php',
    'type' => 'class',
    'override' => false,
  ),
  'PShowSettingsController' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/PShowSettingsController.php',
    'type' => 'class',
    'override' => false,
  ),
  'PShowHook' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/PShowHook.php',
    'type' => 'class',
    'override' => false,
  ),
  'PShowBackupController' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/PShowBackupController.php',
    'type' => 'class',
    'override' => false,
  ),
  'PShowHookController' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/PShowHookController.php',
    'type' => 'class',
    'override' => false,
  ),
  'PShowModule' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/PShowModule.php',
    'type' => 'class',
    'override' => false,
  ),
  'PShowSettingsAbstract' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/PShowSettingsAbstract.php',
    'type' => 'class',
    'override' => false,
  ),
  'PShowAdminController' => 
  array (
    'path' => 'modules/userengage/vendor/system/classes/PShowAdminController.php',
    'type' => 'class',
    'override' => false,
  ),
  'UserEngage' => 
  array (
    'path' => 'modules/userengage/userengage.php',
    'type' => 'class',
    'override' => false,
  ),
);
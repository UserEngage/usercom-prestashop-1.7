USER.COM CHANGELOG
==========

v1.3 - 14/06/2019
-----
* fixed bugs
* fixed forms and translations

v1.2 - 25/02/2019
-----
* improved event on account creation
* fixed bugs

v1.1 - 21/02/2019
-----
* fixed bugs in the newsletter and account creation

v1.0 - 01/02/2019
-----
* implemented full tracking with user.com
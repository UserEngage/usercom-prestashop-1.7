<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */


use Userengage\Engage\Config\Checker;
use Userengage\Engage\Config\ConfigEntry;

class ConfigureUserengageController extends \ModuleAdminController
{
    public function __construct()
    {
        $this->className = 'Configuration';
        $this->table = 'configuration';
        $this->bootstrap = true;

        parent::__construct();

        $translator = Context::getContext()->getTranslator();

        $this->meta_title = $translator->trans('User.com Settings');

        $this->fields_options = [
            'userengage' => [
                'title' => $translator->trans('User.com Settings'),
                'fields' => [
                    ConfigEntry::API_KEY => [
                        'type' => 'text',
                        'title' => $translator->trans('Your app Api Key:'),
                        'desc' => $translator->trans('Please, enter your Api Key (6 characters long).'),
                        'required' => true,
                        'hint' => $translator->trans('You can find an Api Key in the Settings > Setup & Integrations section in the User.com app')
                    ],
                    ConfigEntry::API_ADDRESS => [
                        'type' => 'text',
                        'title' => $translator->trans('Your app subdomain:'),
                        'desc' => $translator->trans('Please, enter your User.com domain name. For example: “your-company.user.com'),
                        'required' => true,
                        'hint' => $translator->trans('You can find a domain name in the Settings > Setup & Integrations section in the User.com app')
                    ],
                    ConfigEntry::REST_API_KEY => [
                        'type' => 'text',
                        'title' => $translator->trans('Your app REST Api key:'),
                        'desc' => $translator->trans('Please enter your app Rest Api key, created under https://your-company.user.com/api/credentials/'),
                        'required' => true,
                        'hint' => $translator->trans('Can be created under Settings > Advanced > Public REST API keys on your User.com app panel')
                    ],
                ],
                'submit' => [
                    'title' => $translator->trans('Save'),
                    'class' => 'btn btn-default pull-right'
                ],
                'buttons' => [
                    [
                        'href' => AdminController::$currentIndex . '&token=' . Tools::getAdminTokenLite('AdminModules'),
                        'title' => $translator->trans('Back to list'),
                        'icon' => 'process-icon-back'
                    ],
                    [
                        'href' => Link::getUrlSmarty(['entity' => 'sf', 'route' => 'userengage_sync']) . '&token=' . Tools::getAdminTokenLite('AdminModules'),
                        'title' => $translator->trans('Sync all data with User.com'),
                        'icon' => 'process-icon-refresh',
                    ],
                ]
            ]
        ];
    }

    public function postProcess()
    {
        if (
            Tools::isSubmit(
            ConfigEntry::API_KEY)
            || Tools::isSubmit(ConfigEntry::REST_API_KEY)
            || Tools::isSubmit(ConfigEntry::API_ADDRESS)
        ) {
            $userengageApiKey = Tools::getValue(ConfigEntry::API_KEY);
            $userengageApp = Tools::getValue(ConfigEntry::API_ADDRESS);
            $userengageRestApiKey = Tools::getValue(ConfigEntry::REST_API_KEY);

            $translator = Context::getContext()->getTranslator();

            if (empty($userengageApiKey) || strlen($userengageApiKey) !== 6) {
                $this->errors[] = ($translator->trans('Invalid User.com Api Key - it should have exactly 6 characters.'));
            }

            if (empty($userengageRestApiKey) || strlen($userengageRestApiKey) !== 64) {
                $this->errors[] = ($translator->trans('Invalid User.com Rest Api Key - it should have exactly 64 characters.'));
            }

            if (
                empty($userengageApp) ||
                !Validate::isUrl($userengageApp) ||
                !$this->endsWithUserComDomain($userengageApp = trim($userengageApp, '/'))
            ) {
                $this->errors[] = ($translator->trans('Invalid User.com App address - it should be valid user.com domain name.'));
            }

            if ($this->errors === []) {
                if (false === strpos($userengageApp, '://')) {
                    $userengageApp = 'https://' . $userengageApp;
                }

                Configuration::updateValue(ConfigEntry::API_KEY, $userengageApiKey);
                Configuration::updateValue(ConfigEntry::API_ADDRESS, $userengageApp);
                Configuration::updateValue(ConfigEntry::REST_API_KEY, $userengageRestApiKey);

                $this->displayInformation($translator->trans('User.com integration settings updated successfully.'));
            }
        }
    }

    private function endsWithUserComDomain(string $haystack): bool
    {
        $needle = 'user.com';

        return substr($haystack, -strlen($needle)) === $needle;
    }
}

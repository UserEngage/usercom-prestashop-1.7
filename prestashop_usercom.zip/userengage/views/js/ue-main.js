/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */
(function () {
    if (typeof prestashop === 'undefined') {
        return
    }

    prestashop.on(
        'updatedProduct',
        function (event) {
            window.currentProductAttributeId = event.id_product_attribute
        }
    )

    prestashop.on(
        'updateCart',
        function (event) {
            if (typeof event.reason.linkAction === "undefined" || event.reason.linkAction !== "add-to-cart" ||
                typeof event.reason.idProduct === "undefined" || !event.resp.success) {
                return
            }
            var currentlyAddedProduct = event.resp.cart.products.find(
                product => product.id == event.reason.idProduct
                    && product.id_product_attribute == event.resp.id_product_attribute
                    && (!Boolean(event.resp.id_customization) || product.id_customization == event.resp.id_customization)
                    && product.cart_quantity == event.resp.quantity
            )

            if (typeof currentlyAddedProduct === "undefined") {
                return;
            }

            userengage(
                'product_event',
                {
                    event_type: "add to cart",
                    product_id: currentlyAddedProduct.id + '-' + currentlyAddedProduct.id_product_attribute,
                    name: currentlyAddedProduct.name,
                    price: currentlyAddedProduct.price,
                    category_name: currentlyAddedProduct.category,
                    image_url: currentlyAddedProduct.cover.large.url,
                    product_url: currentlyAddedProduct.url,
                    SKU: currentlyAddedProduct.reference,
                    quantity: currentlyAddedProduct.cart_quantity,
                }
            )
        }
    );

})()


## [Unreleased] - 2021-11-17

No actions required

### Added

### Changed
- automatic release flow

### Fixed

## [2.0.0-RC1] - 2021-11-17

First version of completely new Prestashop plugin - need to be reinstalled from scratch

### Added
- support for sync previous data
- registered/non-registered user flow

### Changed

### Fixed
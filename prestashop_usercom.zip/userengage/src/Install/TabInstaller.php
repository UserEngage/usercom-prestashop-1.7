<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Install;

use Language;
use Tab;

class TabInstaller implements InstallerInterface
{
    /**
     * Tab installation is required to have admin controller accessible in backoffice
     * @see https://www.prestashop.com/forums/topic/357232-modules-admin-controller-not-found/?tab=comments#comment-1925769
     */
    public function install(\Module $module): bool
    {
        if (Tab::getIdFromClassName('ConfigureUserengage') !== 0) {
            return true;
        }

        $tab = new Tab();
        $tab->class_name = 'ConfigureUserengage';
        $tab->module = $module->name;
        $tab->active = true;
        $tab->enabled = true;
        $tab->id_parent = Tab::getIdFromClassName('Marketing');
        $tab->name = array_fill_keys(
            Language::getIDs(false),
            'User.com'
        );

        $tab->wording = 'User.com';
        $tab->wording_domain = 'Modules.Userengage.Admin';

        return $tab->add();
    }

    public function uninstall(\Module $module): bool
    {
        foreach (Tab::getCollectionFromModule($module->name) as $tab) {
            /** @var Tab $tab */
            $tab->delete();
        }

        return true;
    }
}

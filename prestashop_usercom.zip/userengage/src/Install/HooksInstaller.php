<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Install;

use Configuration;
use Module;
use Shop;
use Userengage\Engage\Config\ConfigEntry;

class HooksInstaller implements InstallerInterface
{
    /** @var string[] */
    private $hooks = [
        'actionAuthentication',
        'actionCarrierProcess',
        'actionCustomerAccountAdd',
        'actionFrontControllerSetMedia',
        'actionFrontControllerSetVariables',
        'actionNewsletterRegistrationAfter',
        'actionObjectCustomerUpdateBefore',
        'actionObjectOrderAddAfter',
        'actionOrderGridDefinitionModifier',
        'actionPaymentConfirmation',
        'displayBeforeBodyClosingTag',
        'filterProductContent',
        'header',
    ];

    public function install(\Module $module): bool
    {
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }

        return array_filter($this->hooks, function (string $hookName) use ($module) {
            return !$module->registerHook($hookName);
        }) === [];
    }

    public function uninstall(\Module $module): bool
    {
        return array_filter($this->hooks, function (string $hookName) use ($module) {
            return !$module->unregisterHook($hookName);
        }) === [];
    }
}

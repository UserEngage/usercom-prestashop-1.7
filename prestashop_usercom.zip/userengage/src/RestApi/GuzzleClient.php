<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\RestApi;

use Context;
use Exception;
use GuzzleHttp\Client as GuzzleHttpClient;
use Userengage\Engage\Event\Backend\ProductCreate;
use Userengage\Engage\Event\Backend\UserCreate;
use Userengage\Engage\Event\Event;
use Userengage\Engage\Event\Product\ProductEvent;
use Userengage\Engage\Log\ExceptionFormatter;

final class GuzzleClient implements Client
{
    /**
     * @var GuzzleHttpClient
     */
    private $httpClient;
    /**
     * @var string
     */
    private $appAddress;
    /**
     * @var string
     */
    private $restApiKey;

    public function __construct(string $restApiKey, string $appAddress, GuzzleHttpClient $httpClient)
    {
        $this->httpClient = $httpClient;
        $this->appAddress = $appAddress;
        $this->restApiKey = $restApiKey;
    }

    public function sendFrontendEvent(Event $event)
    {
        if ($event instanceof ProductEvent) {
            $this->sendProductEvent($event);

            return;
        }

        if ($event instanceof UserCreate) {
            $this->createUser($event);

            return;
        }

        if ($event instanceof ProductCreate) {
            $this->createProduct($event);

            return;
        }

        $eventArray = json_decode($event->asJsonArray(), true);

        $request = $this->httpClient->createRequest(
            'POST',
            "{$this->appAddress}/api/public/users-by-id/{$event->getUserId()}/events/",
            [
                'json' => [
                    "timestamp" => method_exists($event, 'getTime') ? $event->getTime() : time(),
                    'data' => $eventArray,
                    'name' => $event->getName()
                ],
                'headers' => [
                    'Authorization' => "Token {$this->restApiKey}",
                    'Content-Type' => 'application/json',
                ]
            ]
        );

        try {
            $this->httpClient->send($request);
        } catch (Exception $e) {
            if ($e->getCode() === 404) {
                $current_context = Context::getContext();
                if ($current_context->controller->controller_type ===  'front' && !empty($_COOKIE['__ca__chat'])) {
                    $this->sendUsingInternalUserId($event, $_COOKIE['__ca__chat']);
                }
            }

            \PrestaShopLogger::addLog(ExceptionFormatter::formatException($e), 2);
        }
    }

    public function sendProductEvent(ProductEvent $event)
    {
        $eventArray = json_decode($event->asJsonArray(), true);

        try {
            $request = $this->httpClient->createRequest(
                'POST',
                "{$this->appAddress}/api/public/products-by-id/{$eventArray['product_id']}/product_event/",
                [
                    'json' => [
                        'timestamp' => $event->getTime(),
                        'data' => $eventArray,
                        'event_type' => $event->getProductEventName(),
                        'user_id' => $event->getUserId(),
                    ],
                    'headers' => [
                        'Authorization' => "Token {$this->restApiKey}",
                        'Content-Type' => 'application/json',

                    ]
                ]
            );

            $this->httpClient->send($request);
        } catch (Exception $e) {
            \PrestaShopLogger::addLog(ExceptionFormatter::formatException($e), 2);
        }
    }

    public function createUser(UserCreate $event)
    {
        $request = $this->httpClient->createRequest(
            'POST',
            "{$this->appAddress}/api/public/users/",
            [
                'json' => $event->asArray(),
                'headers' => [
                    'Authorization' => "Token {$this->restApiKey}",
                    'Content-Type' => 'application/json',
                ]
            ]
        );

        try {
            $this->httpClient->send($request);
        } catch (Exception $e) {
            $e->getResponse()->getBody()->getContents();
        }
    }

    public function createProduct(ProductCreate $event)
    {
        $event->custom_id = $event->product_id;

        $request = $this->httpClient->createRequest(
            'POST',
            "{$this->appAddress}/api/public/products/",
            [
                'body' => $event->asJsonArray(),
                'headers' => [
                    'Authorization' => "Token {$this->restApiKey}",
                    'Content-Type' => 'application/json'
                ]
            ]
        );

        try {
            $this->httpClient->send($request);
        } catch (Exception $e) {
            \PrestaShopLogger::addLog(ExceptionFormatter::formatException($e), 2);
        }
    }

    private function sendUsingInternalUserId(Event $event, $userKey): void
    {
        try {
            $userData = $this->getUserData($userKey);

            $eventArray = json_decode($event->asJsonArray(), true);

            $request = $this->httpClient->createRequest(
                'POST',
                "{$this->appAddress}/api/public/events/",
                [
                    'json' => [
                        'client' => $userData['id'],
                        'timestamp' => time(),
                        'data' => $eventArray,
                        'name' => $event->getName()
                    ],
                    'headers' => [
                        'Authorization' => "Token {$this->restApiKey}",
                        'Content-Type' => 'application/json',
                    ]
                ]
            );

            $this->httpClient->send($request);
        } catch (\Exception $e) {
            \PrestaShopLogger::addLog(ExceptionFormatter::formatException($e), 2);
        }
    }

    /**
     * @param $userKey
     * @return mixed
     */
    private function getUserData($userKey)
    {
        $response = $this->httpClient->get(
            "{$this->appAddress}/api/public/users/search/",
            [
                'query' => [
                    'key' => $userKey
                ],
                'headers' => [
                    'Authorization' => "Token {$this->restApiKey}",
                ]
            ]
        );

        return json_decode($response->getBody()->getContents(), true);
    }
}

<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Controller;

use Customer;
use Order;
use OrderState;
use PrestaShop\PrestaShop\Adapter\Presenter\Product\ProductLazyArray;
use PrestaShop\PrestaShop\Adapter\Presenter\Product\ProductListingLazyArray;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Userengage\Engage\DTO\ExternalProductId;
use Userengage\Engage\Event\Backend\ProductCreate;
use Userengage\Engage\Event\Backend\UserCreate;
use Userengage\Engage\Event\CartPresenter;
use Userengage\Engage\Event\OrderCompleted;
use Userengage\Engage\Event\Product\AddToCart;
use Userengage\Engage\Event\Purchase;
use Userengage\Engage\Event\UserNewsletterSubscribe;
use Userengage\Engage\Event\UserRegister;
use Userengage\Engage\RestApi\Client;

/**
 * @PrestaShopBundle\Security\Annotation\AdminSecurity("is_granted(['ROLE_EMPLOYEE'], request.get('_legacy_controller'))", message="You do not have permission to update this.")
 */
class SyncController extends FrameworkBundleAdminController
{
    /**
     * @var Client
     */
    private $client;

    public function __construct(Client $client)
    {
        parent::__construct();
        $this->client = $client;
    }

    public function syncAction(Request $request): Response
    {
        $this->preventMaxExecutionTimeExcess();

        $products = [];
        $orders = 0;
        $customers = [];
        foreach (Customer::getCustomers() as ['id_customer' => $customerId]) {
            $this->syncCustomer($customerId);

            foreach (Order::getCustomerOrders($customerId) as ['id_order' => $orderId]) {
                list($products, $orders, $customers) = $this->syncOrder($orderId, $products, $customers, $orders);
            }
            $this->client->reset();
        }

        $this->sendSuccessFlash($products, $orders, $customers);

        return $this->redirectToReferer($request);
    }

    public function bulkSyncOrdersAction(Request $request): Response
    {
        $this->preventMaxExecutionTimeExcess();

        if (empty($orderIds = $request->get('order_orders_bulk'))) {
            $this->addFlash(
                'warning',
                $this->trans(
                    'No orders chosen to sync with User.com!',
                    'Modules.Userengage.Admin'
                )
            );

            return $this->redirectToReferer($request);
        }

        $products = [];
        $orders = 0;
        $customers = [];

        foreach ($orderIds as $orderId) {
            list($products, $orders, $customers) = $this->syncOrder($orderId, $products, $customers, $orders);
        }

        $this->sendSuccessFlash($products, $orders, $customers);

        return $this->redirectToReferer($request);
    }

    public function syncCustomer(int $customerId)
    {
        $customer = new Customer($customerId);

        $this->client->sendFrontendEvent(UserCreate::fromCustomer($customer));
        $this->client->sendFrontendEvent(UserRegister::fromNewCustomer($customer));

        if ($customer->newsletter) {
            $this->client->sendFrontendEvent(UserNewsletterSubscribe::fromCustomer($customer));
        }
    }

    private function preventMaxExecutionTimeExcess(): void
    {
        if (function_exists('set_time_limit')) {
            try {
                set_time_limit(-1);
            } catch (\Throwable $exception) {
            }
        }
    }

    private function redirectToReferer(Request $request): RedirectResponse
    {
        return new RedirectResponse(
            $request->headers->get('referer'),
            302
        );
    }

    public function syncOrder($orderId, array $productsCount, array $customers, int $orders): array
    {
        $order = new Order($orderId);
        $cart = new \Cart($order->id_cart);

        if (!isset($customers[$order->id_customer])) {
            $this->syncCustomer($order->id_customer);
        }

        foreach ($products = array_map(function (array $rawProduct): ProductLazyArray {
            return (new CartPresenter())->presentProduct($rawProduct);
        }, $cart->getProducts()) as $product) {
            if (!$product instanceof ProductListingLazyArray) {
                continue;
            }

            $this->client->sendFrontendEvent(ProductCreate::fromFrontendProductLazyArray($order->id_customer, $product, strtotime($cart->date_add)));
            $this->client->sendFrontendEvent(AddToCart::fromFrontendProductLazyArray($order->id_customer, $product, strtotime($cart->date_add)));
            $productsCount[(new ExternalProductId($product['id_product'], $product['id_product_attribute']))->jsonSerialize()] = null;
        }
        $this->client->sendFrontendEvent(OrderCompleted::fromOrder($order));

        if ($order->hasBeenPaid()) {
            $paidStatus = $order->getHistory((int) $order->id_lang, false, false, OrderState::FLAG_PAID)[0] ?? null;

            foreach ($products as $product) {
                if (!$product instanceof ProductListingLazyArray) {
                    continue;
                }

                $this->client->sendFrontendEvent(
                    \Userengage\Engage\Event\Product\Purchase::fromProductLazyArray(
                        $product,
                        (string)$order->id_customer,
                        $paidStatus ? strtotime($paidStatus['date_add']) : null
                    )
                );
            }

            $this->client->sendFrontendEvent(Purchase::fromOrder($order));
        }

        $orders++;
        $customers[$order->id_customer] = [];

        return [$productsCount, $orders, $customers];
    }

    public function sendSuccessFlash(array $products, int $orders, array $customers): void
    {
        $this->addFlash(
            'success',
            $this->trans(
                'Successfully synced %orders% orders and %products% products for %customers% customers with User.com',
                'Modules.Userengage.Admin',
                [
                    '%products%' => \count($products),
                    '%orders%' => $orders,
                    '%customers%' => \count($customers),
                ]
            )
        );
    }
}

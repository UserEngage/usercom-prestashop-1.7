<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Log;

use GuzzleHttp\Exception\BadResponseException;
use GuzzleHttp\Exception\ClientException;

class ExceptionFormatter
{
    public static function formatException(\Throwable $exception): string
    {
        return self::formatExceptionMessage($exception)
            . self::formatExceptionTrace($exception)
            . self::getCauseIfApplicable($exception);
    }

    private static function formatExceptionMessage(\Throwable $exception): string
    {
        $exceptionClass = get_class($exception);
        $exceptionMessage = "{$exception->getMessage()} ({$exception->getCode()})";

        $fileAndLine = self::formatFileAndLine($exception->getFile(), $exception->getLine());

        if ($exceptionMessage === '') {
            return "${exceptionClass} (${fileAndLine})\n";
        }

        if ($exception instanceof BadResponseException) {
            $exceptionMessage .= ' Response: ' . $exception->getResponse()->getBody()->getContents();
        }

        return "${exceptionClass}: ${exceptionMessage} (${fileAndLine})\n";
    }

    private static function formatFileAndLine($file, $line): string
    {
        return "${file}:${line}";
    }

    private static function formatExceptionTrace(\Throwable $exception): string
    {
        $exceptionTrace = $exception->getTrace();

        $formattedTrace = [];

        foreach ($exceptionTrace as $trace) {
            $formattedTrace[] = "\tat " . self::formatTraceElement($trace);
        }

        return implode("\n", $formattedTrace);
    }

    private static function formatTraceElement($traceElement): string
    {
        $fileAndLine = self::formatFileAndLine(
            isset($traceElement['file']) ? $traceElement['file'] : 'unknown',
            isset($traceElement['line']) ? $traceElement['line'] : 'unknown'
        );

        if (self::isFunctionCall($traceElement)) {
            $functionCall = self::formatFunctionCall($traceElement);
            $arguments = self::formatArguments($traceElement);

            return "${functionCall}(${arguments}) (${fileAndLine})";
        }

        return $fileAndLine;
    }

    private static function isFunctionCall($traceElement): bool
    {
        return array_key_exists('function', $traceElement);
    }

    private static function formatFunctionCall($traceElement): string
    {
        return ($traceElement['class'] ?? '')
            . ($traceElement['type'] ?? '')
            . $traceElement['function'];
    }

    private static function formatArguments($traceElement): string
    {
        /** @var string[] $arguments */
        $arguments = $traceElement['args'];

        $formattedArgs = [];
        foreach ($arguments as $arg) {
            $formattedArgs[] = self::formatArgument($arg);
        }

        return implode(', ', $formattedArgs);
    }

    private static function formatArgument($arg)
    {
        if (is_string($arg)) {
            return "\"" . $arg . "\"";
        } elseif (is_array($arg)) {
            return 'Array';
        } elseif ($arg === null) {
            return 'null';
        } elseif (is_bool($arg)) {
            return $arg ? 'true' : 'false';
        } elseif (is_object($arg)) {
            return get_class($arg);
        } elseif (is_resource($arg)) {
            return get_resource_type($arg);
        } else {
            return $arg;
        }
    }

    private static function getCauseIfApplicable(\Throwable $exception): string
    {
        $previousException = $exception->getPrevious();
        if ($previousException !== null) {
            return "\nCaused by: " . self::formatException($previousException);
        }

        return '';
    }
}

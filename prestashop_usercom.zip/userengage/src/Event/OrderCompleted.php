<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Event;

use Currency;

final class OrderCompleted implements FrontendEvent, BackendEvent
{
    use AsJsonTrait;

    /**
     * @var string
     */
    private $user_id;
    /**
     * @var string
     */
    public $order_number;
    /**
     * @var float
     */
    public $revenue;
    /**
     * @var float
     */
    public $tax;
    /**
     * @var float
     */
    public $shipping;
    /**
     * @var string
     */
    public $currency;
    /**
     * @var string
     */
    public $payment_method;
    /**
     * @var string
     */
    public $coupon;
    /**
     * @var bool
     */
    public $register_user;
    /**
     * @var int
     */
    private $time;

    public function __construct(
        string $userId,
        string $orderNumber,
        float $revenue,
        float $tax,
        float $shipping,
        string $currency,
        string $paymentMethod,
        string $coupon,
        bool $registerUser,
        int $time
    ) {
        foreach ([$revenue, $tax, $shipping] as &$floatValueToBeFormatted) {
            $floatValueToBeFormatted = number_format($floatValueToBeFormatted, 2);
        }

        $this->user_id = $userId;
        $this->order_number = $orderNumber;
        $this->revenue = $revenue;
        $this->tax = $tax;
        $this->shipping = $shipping;
        $this->currency = $currency;
        $this->payment_method = $paymentMethod;
        $this->coupon = $coupon;
        $this->register_user = $registerUser;
        $this->time = $time;
    }

    public static function fromOrder(\Order $order): self
    {
        return new self(
            $order->id_customer,
            $order->id,
            $order->total_paid,
            $order->total_paid_tax_incl - $order->total_paid_tax_excl,
            $order->total_shipping_tax_incl,
            (new Currency($order->id_currency))->getSymbol(),
            $order->payment,
            '',
            !$order->getCustomer()->isGuest(),
            strtotime($order->date_add) ?: time()
        );
    }

    public function getName(): string
    {
        return 'order_completed';
    }

    public function getUserId(): string
    {
        return $this->user_id;
    }

    public function getTime(): int
    {
        return $this->time;
    }
}

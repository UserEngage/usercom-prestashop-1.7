<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Event;

use Customer;
use Userengage\Engage\Event\Filter\Chain;

final class PageHit
{
    use AsJsonTrait;
    /**
     * @var string
     */
    public $unsubscribed;

    /**
     * @var string
     */
    public $apiKey;
    /**
     * @var string
     */
    public $name;
    /**
     * @var string
     */
    public $email;
    /**
     * @var int
     */
    public $gender;
    /**
     * @var int
     */
    public $status;
    /**
     * @var string
     */
    public $user_id;
    /**
     * @var string|null
     */
    public $phone_number;
    /**
     * @var string
     */
    public $address1;
    /**
     * @var string
     */
    public $address2;
    /**
     * @var string
     */
    public $city;
    /**
     * @var string
     */
    public $country;
    /**
     * @var string
     */
    public $postal_code;

    private function __construct(string $apiKey, string $name, string $email, int $gender, int $status, array $attributes)
    {
        $this->apiKey = $apiKey;
        $this->name = $name;
        $this->email = $email;
        $this->gender = $gender;
        $this->status = $status;
        $this->user_id = $attributes['id'] ?? $this->user_id;
        $this->unsubscribed = $attributes['newsletter'] ?? $this->unsubscribed;
        unset($attributes['id'], $attributes['newsletter']);

        foreach ($attributes as $key => $attribute) {
            if ($attribute !== []) {
                $this->{$key} = $attribute;
            }
        }
    }

    public static function fromCustomer(string $apiKey, Customer $customer): self
    {
        return new self(
            $apiKey,
            rtrim($customer->firstname . ' ' . $customer->lastname, ' '),
            $customer->email,
            $customer->id_gender,
            $customer->active ? 1 : 2,
            Chain::create()(json_decode(json_encode($customer), true))
        );
    }

    public static function fromCartAndCustomer(string $apiKey, \Cart $cart, Customer $customer): self
    {
        $self = self::fromCustomer($apiKey, $customer);

        $address = new \Address($cart->id_address_delivery);

        $self->phone_number = $address->phone ?: $address->phone_mobile ?: null;
        $self->address1 = $address->address1;
        $self->address2 = $address->address2;
        $self->city = $address->city;
        $self->country = $address->country;
        $self->postal_code = $address->postcode;

        return $self;
    }

    public static function fromGuest(string $apiKey, Customer $customer): self
    {
        return new self(
            $apiKey,
            $customer->firstname . ($customer->lastname !== '' && $customer->lastname !== '0' ? ' ' . $customer->lastname : ''),
            $customer->email,
            $customer->id_gender,
            $customer->active ? 1 : 2,
            Chain::create()(json_decode(json_encode($customer), true))
        );
    }
}

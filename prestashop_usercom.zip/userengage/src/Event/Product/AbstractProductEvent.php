<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Event\Product;

use ArrayAccess;
use Context;
use Manufacturer;
use Userengage\Engage\DTO\ExternalProductId;
use Userengage\Engage\Event\AsJsonTrait;
use Userengage\Engage\Event\Event;

abstract class AbstractProductEvent implements Event
{
    use AsJsonTrait;

    public $event_type;
    /**
     * @var ExternalProductId
     */
    public $product_id;
    /**
     * @var string
     */
    public $name;
    /**
     * @var string
     */
    public $price;
    /**
     * @var string
     */
    public $category_name;
    /**
     * @var string
     */
    public $image_url;
    /**
     * @var string
     */
    public $product_url;
    /**
     * @var string
     */
    public $SKU;
    /**
     * @var int
     */
    public $quantity;
    /**
     * @var string
     */
    public $EAN;
    /**
     * @var string
     */
    public $brand;
    /**
     * @var ?string
     */
    public $size;
    /**
     * @var string
     */
    private $user_id;
    /**
     * @var int
     */
    private $created_at;

    private function __construct(
        string $userId,
        ExternalProductId $product_id,
        string $name,
        string $price,
        string $category_name,
        string $image_url,
        string $product_url,
        string $SKU,
        int    $quantity,
        string $EAN,
        string $brand,
        int $time,
        string $size = null
    ) {
        $this->product_id = $product_id;
        $this->name = $name;
        $this->price = $price;
        $this->category_name = $category_name;
        $this->image_url = $image_url;
        $this->product_url = $product_url;
        $this->SKU = $SKU;
        $this->quantity = $quantity;
        $this->EAN = $EAN;
        $this->brand = $brand;
        $this->user_id = $userId;
        $this->created_at = $time;
        $this->size = $size;
    }

    public static function fromFrontendProductLazyArray(int $userId, ArrayAccess $product, int $timeOfOccurrence = null): self
    {
        $combination = new \Combination($product['id_product_attribute']);
        $attributes = $combination->getAttributesName(\Context::getContext()->language->id);
        $attribute = array_pop($attributes);

        return new static(
            (string)$userId,
            new ExternalProductId($product['id_product'], $product['id_product_attribute']),
            $product['name'],
            $product['price'],
            $product['category'],
            $product['default_image']['large']['url'],
            Context::getContext()->link->getProductLink(
                $product['id_product'],
                null,
                null,
                null,
                null,
                null,
                $product['id_product_attribute']
            ),
            $product['reference'],
            $product['quantity'],
            $product['ean13'],
            $product['manufacturer_name']
                ? $product['manufacturer_name']
                : Manufacturer::getNameById($product['id_manufacturer']),
            $timeOfOccurrence ?: time(),
            $attribute['name'] ?? null
        );
    }

    public function getName(): string
    {
        return 'product_event';
    }

    public function getProductEventName(): string
    {
        return $this->event_type;
    }

    public function getUserId(): string
    {
        return $this->user_id;
    }

    public function getProductId(): ExternalProductId
    {
        return $this->product_id;
    }

    public function getTime(): int
    {
        return $this->created_at;
    }
}

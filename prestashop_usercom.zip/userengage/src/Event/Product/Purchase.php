<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Event\Product;

use PrestaShop\PrestaShop\Adapter\Presenter\Product\ProductListingLazyArray;
use Userengage\Engage\DTO\ExternalProductId;

final class Purchase implements ProductEvent
{
    /**
     * @var string
     */
    public $event_type = 'purchase';
    /**
     * @var string
     */
    public $user_id;
    /**
     * @var ExternalProductId
     */
    public $product_id;
    /**
     * @var int
     */
    private $time;


    protected function __construct(ExternalProductId $productId, string $user_id, int $time)
    {
        $this->product_id = $productId;
        $this->user_id = $user_id;
        $this->time = $time;
    }

    public static function fromProductArray(array $product, string $userId, int $dateOfOccurrence = null): Purchase
    {
        return new Purchase(new ExternalProductId($product['id_product'], $product['id_product_attribute']), $userId, $dateOfOccurrence ?: time());
    }

    public static function fromProductLazyArray(ProductListingLazyArray $product, string $userId, int $dateOfOccurrence = null): Purchase
    {
        return new Purchase(new ExternalProductId($product['id_product'], $product['id_product_attribute']), $userId, $dateOfOccurrence ?: time());
    }

    public function getName(): string
    {
        return 'product_event';
    }

    public function asJsonArray(): string
    {
        return json_encode($this);
    }

    public function getProductEventName(): string
    {
        return $this->event_type;
    }

    public function getUserId(): string
    {
        return $this->user_id;
    }

    public function getProductId(): ExternalProductId
    {
        return $this->product_id;
    }

    public function getTime(): int
    {
        return $this->time;
    }
}

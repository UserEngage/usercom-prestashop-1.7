<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Event;

use Currency;
use OrderState;

final class Purchase implements FrontendEvent
{
    use AsJsonTrait;

    /**
     * @var string
     */
    public $user_id;
    /**
     * @var string
     */
    public $order_number;
    /**
     * @var float
     */
    public $revenue;
    /**
     * @var float
     */
    public $tax;
    /**
     * @var float
     */
    public $shipping;
    /**
     * @var string
     */
    public $currency;
    /**
     * @var string
     */
    public $payment_method;
    /**
     * @var string
     */
    public $coupon;
    /**
     * @var bool
     */
    public $register_user;
    /**
     * @var bool
     */
    public $payment_confirmation;
    /**
     * @var int
     */
    private $paidAt;

    public function __construct(string $userId, string $orderNumber, float $revenue, float $tax, float $shipping, string $currency, string $paymentMethod, string $coupon, bool $registerUser, bool $paymentConfirmation, int $paidAt)
    {
        foreach ([$revenue, $tax, $shipping] as &$floatValueToBeFormatted) {
            $floatValueToBeFormatted = number_format($floatValueToBeFormatted, 2);
        }

        $this->user_id = $userId;
        $this->order_number = $orderNumber;
        $this->revenue = $revenue;
        $this->tax = $tax;
        $this->shipping = $shipping;
        $this->currency = $currency;
        $this->payment_method = $paymentMethod;
        $this->coupon = $coupon;
        $this->register_user = $registerUser;
        $this->payment_confirmation = $paymentConfirmation;
        $this->paidAt = $paidAt;
    }

    public static function fromOrder(\Order $order): self
    {
        $paidStatus = $order->getHistory((int) $order->id_lang, false, false, OrderState::FLAG_PAID)[0] ?? null;

        return new self(
            $order->id_customer,
            $order->id,
            $order->total_paid,
            $order->total_paid_tax_incl - $order->total_paid_tax_excl,
            $order->total_shipping_tax_incl,
            (new Currency($order->id_currency))->getSymbol(),
            $order->payment,
            '',
            !$order->getCustomer()->isGuest(),
            true,
            $paidStatus ? strtotime($paidStatus['date_add']) : time()
        );
    }

    public function getName(): string
    {
        return 'purchase';
    }

    public function getUserId(): string
    {
        return $this->user_id;
    }

    public function getTime(): int
    {
        return $this->paidAt;
    }
}

<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Event;

use Address;
use Userengage\Engage\Event\Filter\Chain;

final class Order implements FrontendEvent
{
    use AsJsonTrait;
    /**
     * @var int
     */
    public $step;
    /**
     * @var string
     */
    private $user_id;

    private function __construct(int $step, string $userId, array $attributes)
    {
        $this->step = $step;
        $this->user_id = $userId;

        foreach (Chain::create()($attributes) as $name => $value) {
            $this->{$name} = $value;
        }
    }

    public static function fromFormData(int $step, string $userId, array $formData): self
    {
        return new self($step, $userId, $formData);
    }

    public static function fromDeliveryOption(int $step, string $userId, string $shippingName): self
    {
        return new self($step, $userId, ['shipping' => $shippingName]);
    }

    public static function fromAddress(int $step, string $userId, Address $address): self
    {
        return new self(
            $step,
            $userId,
            array_filter(
                $address->getFields(),
                function ($_, string $key) {
                    return in_array($key, ['company', 'lastname', 'firstname', 'vat_number', 'address1', 'address2', 'postcode', 'city', 'other', 'phone'], true);
                },
                ARRAY_FILTER_USE_BOTH
            )
        );
    }

    public function getName(): string
    {
        return 'order';
    }

    public function getUserId(): string
    {
        return $this->user_id;
    }
}

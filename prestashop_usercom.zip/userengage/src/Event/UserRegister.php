<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Event;

use Customer;
use Userengage\Engage\Event\Filter\Chain;

final class UserRegister implements FrontendEvent, BackendEvent
{
    use AsJsonTrait;

    /**
     * @var string
     */
    public $first_name;
    /**
     * @var string
     */
    public $last_name;
    /**
     * @var string
     */
    public $email;
    /**
     * @var string
     */
    public $user_id;
    /**
     * @var int
     */
    private $createdAt;

    public function __construct(string $firstname, string $lastname, string $email, array $attributes, int $createdAt)
    {
        $this->first_name = $firstname;
        $this->last_name = $lastname;
        $this->email = $email;
        $this->createdAt = $createdAt;
        $this->user_id = $attributes['id'] ?? $this->user_id;
        unset($attributes['id']);

        foreach ($attributes as $key => $attribute) {
            if ($attribute !== []) {
                $this->{$key} = $attribute;
            }
        }
    }

    public static function fromNewCustomer(Customer $newCustomer): self
    {
        return new self(
            $newCustomer->firstname,
            $newCustomer->lastname,
            $newCustomer->email,
            Chain::create()(json_decode(json_encode($newCustomer), true)),
            strtotime($newCustomer->date_add) ?: time()
        );
    }

    public function getName(): string
    {
        return 'registration';
    }

    public function getUserId(): string
    {
        return $this->user_id;
    }

    public function getTime(): int
    {
        return $this->createdAt;
    }
}

<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Event\Filter;

class SensitiveDataFilter implements FilterInterface
{
    private $sensitiveFields = [
        'birthday',
        'confirm-addresses',
        'continue',
        'customer_privacy',
        'deleted',
        'firstname',
        'force_id',
        'id_country',
        'id_default_group',
        'id_lang',
        'id_shop',
        'id_shop_group',
        'is_guest',
        'last_passwd_gen',
        'lastname',
        'outstanding_allow_amount',
        'passwd',
        'password',
        'reset_password_token',
        'reset_password_validity',
        'secure_key',
        'submitAddress',
        'token',
        'user_id',
    ];

    public function __invoke(array $data): array
    {
        return array_filter(
            $data,
            function ($_, $key) {
                return !in_array($key, $this->sensitiveFields, true);
            },
            ARRAY_FILTER_USE_BOTH
        );
    }
}

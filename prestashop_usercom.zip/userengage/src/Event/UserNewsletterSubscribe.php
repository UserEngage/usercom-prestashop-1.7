<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

namespace Userengage\Engage\Event;

final class UserNewsletterSubscribe implements FrontendEvent, BackendEvent
{
    use AsJsonTrait;

    /**
     * @var string
     */
    public $email;
    /**
     * @var string
     */
    public $place;
    /**
     * @var string|null
     */
    private $user_id;
    /**
     * @var int
     */
    private $time;

    private function __construct(string $email, string $place, int $time, ?string $userId = null)
    {
        $this->email = $email;
        $this->place = $place;
        $this->user_id = $userId;
        $this->time = $time;
    }

    public static function fromEmail(string $email, string $path): self
    {
        return new self($email, $path, time());
    }

    public static function fromCustomer(\Customer $customer, string $path = '/', int $time = null): self
    {
        return new self($customer->email, $path, $time ?? strtotime($customer->newsletter_date_add) ?: time(), (string)$customer->id);
    }

    public function getName(): string
    {
        return 'newsletter_signup';
    }

    public function getUserId(): ?string
    {
        return $this->user_id;
    }

    public function getTime(): int
    {
        return $this->time;
    }
}

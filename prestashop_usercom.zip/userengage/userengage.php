<?php
/**
 * Copyright User.com Sp. z o.o. (Ltd.) and Contributors
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License version 3.0
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * https://opensource.org/licenses/AFL-3.0
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please email
 * license@prestashop.com, so we can send you a copy immediately.
 *
 * @author    User.com Sp. z o.o. (Ltd.) and Contributors <contact@user.com>
 * @copyright User.com Sp. z o.o. (Ltd.) and Contributors
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License version 3.0
 */

use PrestaShop\PrestaShop\Adapter\Presenter\Product\ProductLazyArray;
use PrestaShop\PrestaShop\Core\Grid\Action\Bulk\Type\SubmitBulkAction;
use PrestaShop\PrestaShop\Core\Grid\Definition\GridDefinition;
use Userengage\Engage\Config\Checker;
use Userengage\Engage\Config\ConfigEntry;
use Userengage\Engage\DTO\ChatConfiguration;
use Userengage\Engage\Event\Backend\ProductCreate;
use Userengage\Engage\Event\CheckoutOption;
use Userengage\Engage\Event\FrontendEvent;
use Userengage\Engage\Event\Order;
use Userengage\Engage\Event\OrderCompleted;
use Userengage\Engage\Event\PageHit;
use Userengage\Engage\Event\Product\Checkout;
use Userengage\Engage\Event\Product\PageView;
use Userengage\Engage\Event\Product\ProductEvent;
use Userengage\Engage\Event\Product\Purchase;
use Userengage\Engage\Event\UserLogin;
use Userengage\Engage\Event\UserNewsletterSubscribe;
use Userengage\Engage\Event\UserRegister;
use Userengage\Engage\Log\FingersCrossedWrapper;
use Userengage\Engage\Install\Installer;
use Userengage\Engage\RestApi\Factory;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/vendor/autoload.php';

class UserEngage extends Module
{
    /**
     * @var FrontendEvent[]
     */
    private $frontendEventsToBeDispatched = [];
    /**
     * @var mixed
     */
    private $currentProduct;

    public function __construct()
    {
        $this->name = 'userengage';
        $this->version = '2.0.0';
        $this->author = 'User.com';
        $this->need_instance = 0;
        $this->tab = 'advertising_marketing';
        $this->bootstrap = true;

        $this->ps_versions_compliancy = [
            'min' => '1.7.5.0',
            'max' => _PS_VERSION_,
        ];

        parent::__construct();

        $translator = $this->getTranslator();

        $this->displayName = $translator->trans(
            'User.com',
            [],
            'Modules.Userengage.Admin'
        );
        $this->description = $translator->trans(
            'User.com plugin for PrestaShop.',
            [],
            'Modules.Userengage.Admin'
        );

        $this->confirmUninstall = $translator->trans(
            'Are you sure you want to uninstall User.com plugin?',
            [],
            'Modules.Userengage.Admin'
        );

        $this->warning = implode(' ', Checker::verify());
    }

    public function install(): bool
    {
        return parent::install() && Installer::create()->install($this);
    }

    public function uninstall(): bool
    {
        return Installer::create()->uninstall($this) && parent::uninstall();
    }

    public function hookHeader(): string
    {
        if (!$this->isInitialized()) {
            return '';
        }

        return FingersCrossedWrapper::wrap(function () {
            $isLogged = Context::getContext()->customer->isLogged();
            $userEngageAPIKey = Tools::safeOutput(Configuration::get(ConfigEntry::API_KEY));
            $userEngageAPPAddress = Tools::safeOutput(Configuration::get(ConfigEntry::API_ADDRESS));

            if ($isLogged) {
                $chatConfiguration = ChatConfiguration::forUser(
                    $userEngageAPIKey,
                    Context::getContext()->customer->firstname,
                    Context::getContext()->customer->lastname,
                    # gender ID is "1" or "2" (string)
                    Context::getContext()->customer->id_gender ? 'male' : 'female',
                    Context::getContext()->customer->birthday
                );
            } else {
                $chatConfiguration = ChatConfiguration::forGuest($userEngageAPIKey);
            }

            return <<<HTML
<script data-cfasync="false" type="text/javascript">
window.civchat = {$chatConfiguration}
</script>
<script data-cfasync="false" type="text/javascript" src="{$userEngageAPPAddress}/widget.js"></script>
HTML;
        }, '');
    }

    private function isInitialized(): bool
    {
        return empty($this->warning);
    }

    public function hookDisplayBeforeBodyClosingTag(array $params): string
    {
        return FingersCrossedWrapper::wrap(function () use ($params) {
            $userEngageAPIKey = Tools::safeOutput(Configuration::get(ConfigEntry::API_KEY));
            if ($this->context->cookie->registration) {
                $this->context->cookie->__unset('registration');
                $this->frontendEventsToBeDispatched[] = PageHit::fromCustomer($userEngageAPIKey, $this->context->customer);
            }

            if ($this->context->cookie->login) {
                $this->context->cookie->__unset('login');
                $this->frontendEventsToBeDispatched[] = PageHit::fromCustomer($userEngageAPIKey, $this->context->customer);
            }

            if ($this->context->cookie->address) {
                $this->context->cookie->__unset('address');

                $this->frontendEventsToBeDispatched[] = PageHit::fromCartAndCustomer(
                    $userEngageAPIKey,
                    $this->context->cart,
                    $this->context->customer
                );
            }

            $html = '<script data-cfasync="false" type="text/javascript">';
            foreach ($this->frontendEventsToBeDispatched as $frontendEvent) {
                if ($frontendEvent instanceof FrontendEvent) {
                    $eventName = $frontendEvent instanceof ProductEvent
                        ? $frontendEvent->getName()
                        : 'event.' . $frontendEvent->getName();

                    $html .= <<<JS
userengage('{$eventName}', {$frontendEvent->asJsonArray()})

JS;
                }
                if ($frontendEvent instanceof PageHit) {
                    $html .= <<<JS
UE.pageHit({$frontendEvent->asJsonArray()})

JS;
                }
            }
            $this->frontendEventsToBeDispatched = [];
            $html .= '</script>';

            if (isset($this->currentProduct)) {
                $html .= <<<HTML
<script data-cfasync="false" type="text/javascript">
window.currentProductId = "{$this->currentProduct['id']}"
window.currentProductAttributeId = "{$this->currentProduct['id_product_attribute']}"
</script>
HTML;
            }

            return $html;
        }, '');
    }

    public function hookActionCustomerAccountAdd(array $params): void
    {
        if (!$this->isInitialized()) {
            return;
        }

        if (empty($params['newCustomer'])) {
            return;
        }

        FingersCrossedWrapper::wrap(function () use ($params) {
            $this->frontendEventsToBeDispatched[] = UserRegister::fromNewCustomer($params['newCustomer']);

            if ($params['newCustomer']->newsletter) {
                $this->frontendEventsToBeDispatched[] = UserNewsletterSubscribe::fromCustomer(
                    $params['newCustomer'],
                    $_SERVER['HTTP_REFERER']
                );
            }

            $this->context->cookie->registration = 1;
        });
    }

    public function hookActionObjectCustomerUpdateBefore($params)
    {
        if (empty($params['object']) || !$params['object'] instanceof Customer) {
            return;
        }

        FingersCrossedWrapper::wrap(function () use ($params) {
            $currentCustomerData = new Customer($params['object']->id);
            if ($currentCustomerData->newsletter != $params['object']->newsletter) {
                if ($params['object']->newsletter) {
                    $this->frontendEventsToBeDispatched[] = UserNewsletterSubscribe::fromCustomer(
                        $params['object'],
                        $_SERVER['HTTP_REFERER'],
                        time()
                    );
                }
            }

            $this->context->cookie->login = 1;
        });
    }

    public function hookActionAuthentication(array $params): void
    {
        if (!$this->isInitialized()) {
            return;
        }

        if (empty($params['customer'])) {
            return;
        }
        FingersCrossedWrapper::wrap(function () use ($params) {
            if ($this->context->customer->email !== null) {
                $this->frontendEventsToBeDispatched[] = UserLogin::fromCustomer($params['customer']);
            }

            $this->context->cookie->login = 1;
        });
    }

    public function hookActionCarrierProcess(array $params): void
    {
        if (!$this->isInitialized()) {
            return;
        }

        FingersCrossedWrapper::wrap(function () use ($params) {
            if ($_GET['controller'] === 'order') {
                if (isset($_POST['firstname'], $_POST['lastname'], $_POST['email'])) {
                    $this->frontendEventsToBeDispatched[] = Order::fromFormData(1, (string)$this->context->customer->id, $_POST);
                }
                if (isset($_POST['firstname'], $_POST['lastname'], $_POST['address1'], $_POST['postcode'], $_POST['city'])) {
                    $this->frontendEventsToBeDispatched[] = Order::fromFormData(2, (string)$this->context->customer->id, $_POST);
                    $this->context->cookie->address = 1;
                }
                if (isset($_POST['id_address_delivery'])) {
                    $this->frontendEventsToBeDispatched[] = Order::fromAddress(2, (string)$this->context->customer->id, new Address($_POST['id_address_delivery']));
                    $this->context->cookie->address = 1;
                }
                if (isset($_POST['delivery_option'], $_POST['confirmDeliveryOption'], $params['cart']) && $_POST['confirmDeliveryOption']) {
                    /** @var Cart $cart */
                    $cart = $params['cart'];

                    if (($carrier = new Carrier(rtrim(current($cart->getDeliveryOption()), ','))) && $carrier->name) {
                        $this->frontendEventsToBeDispatched[] = Order::fromDeliveryOption(
                            3,
                            (string)$this->context->customer->id,
                            $carrier->name
                        );
                    }
                }

                if (isset($_POST['delivery_message']) && !empty($_POST['delivery_message'])) {
                    $this->frontendEventsToBeDispatched[] = CheckoutOption::fromAdditionalMessage((string)$this->context->customer->id, $_POST['delivery_message']);
                }
            }
        });
    }

    public function hookActionObjectOrderAddAfter($params): void
    {
        if (!$this->isInitialized()) {
            return;
        }

        FingersCrossedWrapper::wrap(function () use ($params) {
            $this->frontendEventsToBeDispatched[] = Order::fromFormData(
                4,
                (string)$this->context->customer->id,
                ['payment_method' => $params['object']->payment]
            );
            $this->frontendEventsToBeDispatched[] = OrderCompleted::fromOrder($params['object']);
        });
    }

    /**
     * @param array{email: string, action: string} $params
     */
    public function hookActionNewsletterRegistrationAfter(array $params): void
    {
        if (!$this->isInitialized()) {
            return;
        }

        $this->frontendEventsToBeDispatched[] = UserNewsletterSubscribe::fromEmail(
            $params['email'],
            $_SERVER['HTTP_REFERER'] ?? $params['action'] ?? ''
        );
    }

    public function hookActionFrontControllerSetMedia(): void
    {
        if (!$this->isInitialized()) {
            return;
        }

        $this->context->controller->registerJavascript(
            'userengage-main',
            $this->_path . 'views/js/ue-main.js'
        );

        $this->context->controller->registerJavascript(
            'userengage-blockwishlist-support',
            $this->_path . 'views/js/ue-blockwishlist.js',
            [
                'position' => 'top',
                //after blockwishlist/public/product.bundle.js
                'priority' => 101,
            ]
        );

        $this->context->controller->registerJavascript(
            'userengage-blocksocial-support',
            $this->_path . 'views/js/ue-blocksocial.js'
        );
    }

    public function hookActionFrontControllerSetVariables(array $params): void
    {
        if (!$this->isInitialized()) {
            return;
        }

        FingersCrossedWrapper::wrap(function () use ($params) {
            if (isset(
                $params['cart'],
                $params['templateVars'],
                $params['templateVars']['page'],
                $params['templateVars']['page']['page_name'],
                $params['templateVars']['cart'],
                $params['templateVars']['cart']['products']
            )) {
                /** @var Cart $cart */
                $cart = $params['cart'];

                if (
                    $params['templateVars']['page']['page_name'] === 'cart'
                    && isset($_GET['action'])
                    && $_GET['action'] === 'show'
                ) {
                    foreach ($params['templateVars']['cart']['products'] as $product) {
                        $this->frontendEventsToBeDispatched[] = Checkout::fromFrontendProductLazyArray($cart->id_customer, $product);
                    }
                }
            }
        });
    }

    public function hookFilterProductContent(array $params): void
    {
        if (!$this->isInitialized()) {
            return;
        }

        FingersCrossedWrapper::wrap(function () use ($params) {
            if (
                isset($params['object'], $params['cart'])
                && $params['object'] instanceof ProductLazyArray
            ) {
                $userId = (int)($params['cart']->id_customer ?: $params['cart']->id_guest);
                $this->frontendEventsToBeDispatched[] = ProductCreate::fromFrontendProductLazyArray($userId, $params['object']);
                $this->frontendEventsToBeDispatched[] = PageView::fromFrontendProductLazyArray($userId, $params['object']);

                $this->currentProduct = $params['object'];
            }
        });
    }

    public function hookActionPaymentConfirmation(array $params): void
    {
        if (!$this->isInitialized()) {
            return;
        }

        FingersCrossedWrapper::wrap(function () use ($params) {
            /** @var \Order $order */
            $order = new \Order($params['id_order']);
            foreach ($order->getCartProducts() as $product) {
                $this->frontendEventsToBeDispatched[] = Purchase::fromProductArray($product, (string)$order->id_customer, $order->hasBeenPaid());
            }
            $this->frontendEventsToBeDispatched[] = \Userengage\Engage\Event\Purchase::fromOrder($order);
        });
    }

    public function getContent(): void
    {
        Tools::redirectAdmin($this->context->link->getAdminLink('ConfigureUserengage'));
    }

    public function hookActionOrderGridDefinitionModifier(array $params): void
    {
        if (!$this->isInitialized()) {
            return;
        }

        FingersCrossedWrapper::wrap(function () use ($params) {
            if ($params['definition'] instanceof GridDefinition) {
                $params['definition']->getBulkActions()->add(
                    (new SubmitBulkAction('ue_sync_orders'))
                        ->setName('Sync orders with User.com')
                        ->setOptions([
                            // in most cases submit action should be implemented by module
                            'submit_route' => 'userengage_sync_orders_bulk',
                        ])
                );
            }
        });
    }

    public function __destruct()
    {
        FingersCrossedWrapper::wrap(function () {
            if ($this->frontendEventsToBeDispatched === []) {
                return;
            }

            $client = Factory::createBuffered();

            /** @var Purchase $event */
            while ($event = array_shift($this->frontendEventsToBeDispatched)) {
                $client->sendFrontendEvent($event);
            }
        });
    }
}

# User.com integration for Prestashop 1.7

### Development

To have local environment up and running: 
 - install docker with compose
 - run `docker compose up -d`
 - copy prestashop core files to volume `docker compose exec php sh -c " /var/www/prestashop/* /var/www/html -r"`
 - add docker-compose override `cp docker-compose.override.yml.dist docker-compose.override.yml` 
   to mount local module file inside prestashop
 - run `docker compose up -d`

Shop should be available under [prestashop.localhost](http://prestashop.localhost).